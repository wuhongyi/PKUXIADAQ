Pixie-16 C API Example
######################

``example_pixie16api`` compiles and links against ``Pixie16Api.so``.
This library provides users a C wrapper to the ``PixieSDK``. We also
provide a python example that uses the same configuration file and
library.

See https://docs.pixie16.xia.com/user/examples/example_pixie16api.html for more info on the C API example