# PixieSDK - Examples

We provide some basic programs that you can use to test the functionality of the API. These programs
do not encompass the full functionality of the API. They are **not recommended for production use**.

## Examples

* [example_pixie16api](example_pixie16api/README.md)
* [data_visualizer](data_visualizer/README.md)
