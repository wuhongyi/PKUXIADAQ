# PixieSDK Test Suite

The test suite contains programs related to testing performance and functionality of the software.
We use [doctest](https://github.com/onqtam/doctest) as our test framework.