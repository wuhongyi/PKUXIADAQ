# Broadcom PCI/PCIe SDK
This is a version of the [Broadcom PCI/PCIe SDK](https://www.broadcom.com/products/pcie-switches-bridges/software-dev-kits) 
for Linux. Broadcom licensed the SDK under the GNU GPL v2, which is available in the LICENSE file 
provided with this repository. 

XIA LLC maintains this version for their dependent products. This version of the SDK has been tested
and verified as working with our products. 

## Disclaimer
Broadcom in no way supports or endorses this version of the PCI/PCIe SDK. 

