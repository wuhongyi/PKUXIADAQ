/// @file test.cpp
/// @brief
/// @author S. V. Paulauskas
/// @date November 23, 2020

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"