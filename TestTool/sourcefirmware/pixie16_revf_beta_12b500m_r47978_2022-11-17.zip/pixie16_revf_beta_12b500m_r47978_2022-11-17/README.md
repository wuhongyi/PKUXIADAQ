# Pixie-16 Rev F 12-500 Beta Firmware
## Change Log
* Updates timing in fpeak_pixie16.v to ensure that QDC sum collection doesn't halt data collection.

## Licensing
This file and all associated files are covered by the XIA LLC Firmware Licence Version 1.0.