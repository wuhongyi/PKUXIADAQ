# Pixie-16 Rev F 12-500 Beta Firmware
## Change Log
* Fixes issue in fpeak_pixie16.v from r45405 that caused data recording to stop during a data run.

## Licensing
This file and all associated files are covered by the XIA LLC Firmware Licence Version 1.0.